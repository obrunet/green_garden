class PremiumEmail < ApplicationRecord
end
