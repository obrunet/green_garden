require 'test_helper'

class PremiumEmailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
